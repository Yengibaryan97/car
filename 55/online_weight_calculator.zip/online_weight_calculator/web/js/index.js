let query = document.getElementById('query');
let wrapper = document.getElementById('wrapper');
let send_message = document.getElementById('send');
let clear = document.getElementById('clear');
let otput = document.getElementById('output');
let loading = document.getElementById('lds-dual-ring');
let create_tree = true;
let query_value;
let swarm_response;

send_message.addEventListener('click', request);
send_message.addEventListener('click', clear_textarea);
clear.addEventListener('click', clear_textarea);


let socket = new WebSocket("wss://eu-swarm-cf.betconstruct.com");


function socket_send() {
    socket.send('{"command":"request_session","params":{"language":"eng","site_id":1},"rid":"112"}');
}

socket.onopen = socket_send;

socket.onmessage = function (event) {
    check_events(event.data);
    swarm_response = JSON.parse(event.data);

    if (swarm_response['code'] === 0 && swarm_response['rid'] === '112') {
    } else {
        get_weight(swarm_response, '_weight');
        if (create_tree === true) {
            let tree = jsonTree.create(swarm_response, wrapper);
        }
        create_tree = true;
        loading.style.opacity = "0";
    }
};

socket.onclose = function (event) {
    socket_send()
};

socket.onerror = function (error) {
    alert(`[error] ${error.message}`);
};

function request() {
    loading.style.opacity = "1";
    query_value = query.value;
    try {
        query_value = JSON.stringify(change_subscription(JSON.parse(query_value), 'subscribe'));
        query_value = JSON.stringify(add_weight(JSON.parse(query_value)));
    } catch (e) {}
    socket.send(query_value);
}

function clear_textarea() {
    wrapper.innerHTML = '';
    otput.innerHTML = '';
}


function check_events(dict) {
    if (dict.length > 200000) {
        create_tree = false
    }
}

function get_weight(dict, word) {
    try {
        let weight = dict['data']['data'][word];

        if (weight === undefined) {
            otput.innerHTML = "No weight.";
            return
        } else if (weight >= 2000) {
            otput.style.color = 'red'
        } else {
            otput.style.color = 'green'
        }
        otput.innerHTML = weight;
    } catch (e) {
        otput.innerHTML = "No weight."
    }
}

function add_weight(command_query) {
    try {
        command_query['params']['weight'] = true
    } catch (e) {}
    return command_query
}

function change_subscription(dict, word) {
    dict['params'][word] = false;
    return dict
}
